import React from 'react';

const ArticlesList = () => (
    <>
    <h1>Articles</h1>
    </>
);

export default ArticlesList;