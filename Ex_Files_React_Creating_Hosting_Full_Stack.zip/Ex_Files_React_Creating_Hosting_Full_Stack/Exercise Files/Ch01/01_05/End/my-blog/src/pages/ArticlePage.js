import React from 'react';

const ArticlePage = () => (
    <>
    <h1>This is an article</h1>
    </>
);

export default ArticlePage;